import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { useState, useEffect } from 'react'
import Landing from './pages/Landing'
import Login from './pages/Login'
import Register from './pages/Register'
import Dashboard from './pages/Dashboard'
import Projects from './pages/Projects'
import ProjectDetail from './pages/ProjectDetail'
import Profile from './pages/Profile'
import Messages from './pages/Messages'
import Contracts from './pages/Contracts'
import FindFreelancers from './pages/FindFreelancers'
import Layout from './components/Layout'

function App() {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const token = localStorage.getItem('token')
    const userData = localStorage.getItem('user')
    if (token && userData) {
      setUser(JSON.parse(userData))
    }
    setLoading(false)
  }, [])

  if (loading) return <div className="flex items-center justify-center h-screen">Loading...</div>

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={!user ? <Landing /> : <Navigate to="/dashboard" />} />
        <Route path="/login" element={!user ? <Login setUser={setUser} /> : <Navigate to="/dashboard" />} />
        <Route path="/register" element={!user ? <Register setUser={setUser} /> : <Navigate to="/dashboard" />} />
        
        <Route element={user ? <Layout user={user} setUser={setUser} /> : <Navigate to="/" />}>
          <Route path="dashboard" element={<Dashboard user={user} />} />
          <Route path="projects" element={<Projects user={user} />} />
          <Route path="projects/:id" element={<ProjectDetail user={user} />} />
          <Route path="profile" element={<Profile user={user} />} />
          <Route path="messages" element={<Messages user={user} />} />
          <Route path="contracts" element={<Contracts user={user} />} />
          <Route path="find-freelancers" element={<FindFreelancers user={user} />} />
        </Route>
      </Routes>
    </BrowserRouter>
  )
}

export default App
