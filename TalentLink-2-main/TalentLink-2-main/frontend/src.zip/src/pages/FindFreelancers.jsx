import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { ChevronLeft, ChevronRight, MessageSquare, Star, MapPin, DollarSign, X, Heart } from 'lucide-react'
import api from '../api/axios'

export default function FindFreelancers({ user }) {
  const navigate = useNavigate()
  const [freelancers, setFreelancers] = useState([])
  const [currentIndex, setCurrentIndex] = useState(0)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchFreelancers()
  }, [])

  const fetchFreelancers = async () => {
    try {
      const res = await api.get('/freelancers')
      setFreelancers(res.data)
    } catch (err) {
      console.error('Error fetching freelancers:', err)
    } finally {
      setLoading(false)
    }
  }

  const handleNext = () => {
    if (currentIndex < freelancers.length - 1) {
      setCurrentIndex(currentIndex + 1)
    }
  }

  const handlePrevious = () => {
    if (currentIndex > 0) {
      setCurrentIndex(currentIndex - 1)
    }
  }

  const handleMessage = (freelancerId) => {
    navigate(`/messages?user=${freelancerId}`)
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-xl text-gray-600">Loading freelancers...</div>
      </div>
    )
  }

  if (freelancers.length === 0) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-2">No Freelancers Found</h2>
          <p className="text-gray-600">Check back later for available freelancers</p>
        </div>
      </div>
    )
  }

  const currentFreelancer = freelancers[currentIndex]

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Find Freelancers</h1>
          <p className="text-gray-600">Browse through talented freelancers</p>
          <div className="mt-4 text-sm text-gray-500">
            {currentIndex + 1} of {freelancers.length}
          </div>
        </div>

        <div className="relative">
          {/* Card */}
          <div className="bg-white rounded-2xl shadow-2xl overflow-hidden transform transition-all duration-300 hover:scale-[1.02]">
            {/* Profile Header */}
            <div className="bg-gradient-to-r from-blue-600 to-purple-600 h-32"></div>
            
            {/* Profile Content */}
            <div className="p-8 -mt-16">
              {/* Avatar */}
              <div className="flex justify-center mb-4">
                <div className="w-32 h-32 rounded-full bg-white border-4 border-white shadow-lg flex items-center justify-center text-4xl font-bold text-blue-600">
                  {currentFreelancer.name.charAt(0).toUpperCase()}
                </div>
              </div>

              {/* Name and Rating */}
              <div className="text-center mb-6">
                <h2 className="text-3xl font-bold text-gray-900 mb-2">
                  {currentFreelancer.name}
                </h2>
                <div className="flex items-center justify-center space-x-2 text-yellow-500 mb-2">
                  <Star className="w-5 h-5 fill-current" />
                  <span className="text-lg font-semibold text-gray-700">
                    {currentFreelancer.rating || '5.0'}
                  </span>
                  <span className="text-gray-500">
                    ({currentFreelancer.reviews_count || 0} reviews)
                  </span>
                </div>
                {currentFreelancer.location && (
                  <div className="flex items-center justify-center text-gray-600">
                    <MapPin className="w-4 h-4 mr-1" />
                    {currentFreelancer.location}
                  </div>
                )}
              </div>

              {/* Hourly Rate */}
              {currentFreelancer.hourly_rate && (
                <div className="flex items-center justify-center mb-6">
                  <div className="bg-green-100 text-green-800 px-6 py-3 rounded-full flex items-center space-x-2">
                    <DollarSign className="w-5 h-5" />
                    <span className="text-xl font-bold">{currentFreelancer.hourly_rate}/hr</span>
                  </div>
                </div>
              )}

              {/* Bio */}
              <div className="mb-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">About</h3>
                <p className="text-gray-700 leading-relaxed">
                  {currentFreelancer.bio || 'No bio available'}
                </p>
              </div>

              {/* Skills */}
              {currentFreelancer.skills && currentFreelancer.skills.length > 0 && (
                <div className="mb-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-3">Skills</h3>
                  <div className="flex flex-wrap gap-2">
                    {currentFreelancer.skills.map((skill, i) => (
                      <span
                        key={i}
                        className="px-4 py-2 bg-blue-100 text-blue-700 rounded-full text-sm font-medium"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Portfolio Link */}
              {currentFreelancer.portfolio_url && (
                <div className="mb-6">
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">Portfolio</h3>
                  <a
                    href={currentFreelancer.portfolio_url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-600 hover:text-blue-700 underline"
                  >
                    {currentFreelancer.portfolio_url}
                  </a>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex justify-center space-x-4 mt-8">
                <button
                  onClick={handlePrevious}
                  disabled={currentIndex === 0}
                  className="p-4 bg-gray-200 text-gray-700 rounded-full hover:bg-gray-300 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                  title="Previous"
                >
                  <X className="w-6 h-6" />
                </button>
                
                <button
                  onClick={() => handleMessage(currentFreelancer.id)}
                  className="px-8 py-4 bg-blue-600 text-white rounded-full hover:bg-blue-700 flex items-center space-x-2 transition-all transform hover:scale-105"
                >
                  <MessageSquare className="w-5 h-5" />
                  <span className="font-semibold">Message</span>
                </button>

                <button
                  onClick={handleNext}
                  disabled={currentIndex === freelancers.length - 1}
                  className="p-4 bg-green-500 text-white rounded-full hover:bg-green-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                  title="Next"
                >
                  <Heart className="w-6 h-6" />
                </button>
              </div>
            </div>
          </div>

          {/* Navigation Arrows */}
          <button
            onClick={handlePrevious}
            disabled={currentIndex === 0}
            className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-16 p-3 bg-white rounded-full shadow-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <ChevronLeft className="w-8 h-8 text-gray-700" />
          </button>

          <button
            onClick={handleNext}
            disabled={currentIndex === freelancers.length - 1}
            className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-16 p-3 bg-white rounded-full shadow-lg hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <ChevronRight className="w-8 h-8 text-gray-700" />
          </button>
        </div>

        {/* Keyboard Shortcuts Hint */}
        <div className="text-center mt-8 text-sm text-gray-500">
          <p>Use ← → arrow keys to navigate</p>
        </div>
      </div>
    </div>
  )
}
