import { useState, useEffect, useRef } from 'react'
import { Send, User as UserIcon, Search } from 'lucide-react'
import { useSearchParams, useNavigate } from 'react-router-dom'
import api from '../api/axios'

export default function Messages({ user }) {
  const [searchParams] = useSearchParams()
  const navigate = useNavigate()
  const [conversations, setConversations] = useState([])
  const [selectedUser, setSelectedUser] = useState(null)
  const [messages, setMessages] = useState([])
  const [newMessage, setNewMessage] = useState('')
  const [searchTerm, setSearchTerm] = useState('')
  const messagesEndRef = useRef(null)

  // Fetch conversations list and handle URL parameter
  useEffect(() => {
    const fetchConversations = async () => {
      try {
        console.log('Fetching conversations...')
        const res = await api.get('/conversations', {
          withCredentials: true,
          headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
          }
        })
        
        if (!res.data) {
          console.error('No data received from server')
          return
        }
        
        if (!Array.isArray(res.data)) {
          console.error('Expected an array of conversations, got:', typeof res.data)
          return
        }
        
        console.log('Fetched conversations:', res.data)
        setConversations(res.data)
        
        // Get user ID from URL
        const userId = searchParams.get('user')
        console.log('User ID from URL:', userId)
        
        // If user ID is provided in URL
        if (userId && userId !== 'undefined' && userId !== 'null') {
          const userIdNum = parseInt(userId, 10)
          if (!isNaN(userIdNum)) {
            console.log('Looking for user with ID:', userIdNum)
            const matchedUser = res.data.find(u => u.id === userIdNum)
            console.log('Matched user:', matchedUser)
            
            if (matchedUser) {
              // Found existing conversation
              console.log('Setting selected user from URL:', matchedUser)
              setSelectedUser(matchedUser)
            } else {
              // User not in conversations yet - fetch user info and create new conversation
              console.log('User not in conversations, fetching user info...')
              try {
                const userRes = await api.get(`/users/${userIdNum}`)
                const newUser = {
                  id: userRes.data.id,
                  name: userRes.data.name,
                  role: userRes.data.role,
                  last_message: null,
                  unread_count: 0,
                  is_online: false
                }
                console.log('Setting new user:', newUser)
                setSelectedUser(newUser)
                // Don't add to conversations yet - will be added after first message
              } catch (userErr) {
                console.error('Error fetching user info:', userErr)
                // If we can't fetch user, fall back to first conversation
                if (res.data.length > 0) {
                  console.log('Falling back to first conversation:', res.data[0])
                  setSelectedUser(res.data[0])
                  navigate(`/messages?user=${res.data[0].id}`, { replace: true })
                }
              }
            }
          }
        } else if (res.data.length > 0) {
          // No user ID in URL, select first conversation
          console.log('No user selected, defaulting to first conversation:', res.data[0])
          setSelectedUser(res.data[0])
          navigate(`/messages?user=${res.data[0].id}`, { replace: true })
        } else {
          console.log('No conversations available')
        }
      } catch (err) {
        console.error('Error fetching conversations:', err)
      }
    }
    
    fetchConversations()
  }, [searchParams, navigate])

  // Handle conversation selection
  const handleSelectConversation = (user) => {
    console.log('Selecting conversation with user:', user);
    setSelectedUser(user)
    navigate(`/messages?user=${user.id}`)
  }

  // Fetch messages when selected user changes
  useEffect(() => {
    if (selectedUser && selectedUser.id) {
      console.log('Selected user changed:', selectedUser);
      fetchMessages()
      const interval = setInterval(fetchMessages, 3000) // Poll every 3 seconds
      return () => clearInterval(interval)
    } else {
      console.log('No user selected or user ID is missing');
    }
  }, [selectedUser?.id])

  // Auto-scroll to bottom when messages change
  useEffect(() => {
    scrollToBottom()
  }, [messages])

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  const fetchMessages = async () => {
  if (!selectedUser?.id) {
    console.error('No user selected or invalid user ID');
    return;
  }

  try {
    console.log('Fetching messages for user ID:', selectedUser.id);
    const res = await api.get(`/messages?user_id=${selectedUser.id}`, {
      withCredentials: true,
      headers: {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
      }
    });
    
    if (!res.data) {
      console.error('No data received from server');
      return;
    }
    
    if (!Array.isArray(res.data)) {
      console.error('Expected an array of messages, got:', typeof res.data);
      return;
    }

    console.log('Fetched messages:', res.data);
    
    // Transform the messages to match the expected format
    const formattedMessages = res.data.map(msg => ({
      id: msg.id,
      content: msg.content,
      timestamp: msg.timestamp || new Date().toISOString(),
      is_sender: msg.sender_id === user.id,
      is_read: msg.is_read,
      read_at: msg.read_at
    }));

    setMessages(formattedMessages);
    
    // Mark messages as read
    if (formattedMessages.length > 0) {
      const unreadMessages = formattedMessages.filter(
        msg => !msg.is_sender && !msg.is_read
      );
      
      if (unreadMessages.length > 0) {
        try {
          // Only mark as read if we have message IDs
          const messageIds = unreadMessages.map(msg => msg.id).filter(Boolean);
          if (messageIds.length > 0) {
            await api.post('/messages/mark-read', {
              message_ids: messageIds
            }, {
              withCredentials: true,
              headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
              }
            });
            
            // Update local state to reflect read status
            setMessages(prevMessages => 
              prevMessages.map(msg => 
                unreadMessages.some(m => m.id === msg.id) 
                  ? { ...msg, is_read: true } 
                  : msg
              )
            );
          }
        } catch (error) {
          console.error('Error marking messages as read:', error);
          // Continue execution even if marking as read fails
        }
      }
    }
  } catch (error) {
    console.error('Error fetching messages:', error);
    if (error.response) {
      console.error('Response data:', error.response.data);
      console.error('Response status:', error.response.status);
    }
  }
};

  const handleSendMessage = async (e) => {
    e.preventDefault();
    const messageContent = newMessage.trim();
    if (!messageContent || !selectedUser) return;

    try {
      // Optimistically update UI
      const tempMessage = {
        id: `temp-${Date.now()}`, // Temporary ID with prefix
        content: messageContent,
        timestamp: new Date().toISOString(),
        is_read: false,
        is_sender: true,
        isSending: true
      };
      
      setMessages(prev => [...prev, tempMessage]);
      setNewMessage('');
      scrollToBottom();

      // Send to server
      await api.post('/messages', {
        receiver_id: selectedUser.id,
        content: messageContent
      })
      
      // Refresh messages to get the actual message from server
      await fetchMessages()
      
      // Refresh conversations to update the last message
      const res = await api.get('/conversations')
      const updatedConversations = res.data
      setConversations(updatedConversations)
      
      // If this was a new conversation, update the selected user with conversation data
      if (!conversations.find(c => c.id === selectedUser.id)) {
        const newConv = updatedConversations.find(c => c.id === selectedUser.id)
        if (newConv) {
          setSelectedUser(newConv)
        }
      }
    } catch (err) {
      console.error('Error sending message:', err)
      // Remove the optimistic message on error
      setMessages(prev => prev.filter(m => !m.isSending))
    }
  }

  const filteredConversations = conversations.filter(conv => 
    conv.name.toLowerCase().includes(searchTerm.toLowerCase())
  )

  return (
    <div className="h-screen flex flex-col">
      <div className="p-6 pb-0">
        <h1 className="text-3xl font-bold text-gray-900">Messages</h1>
      </div>

      <div className="flex-1 flex flex-col bg-white rounded-t-lg shadow-lg overflow-hidden m-4 mb-0">
        <div className="flex flex-1 overflow-hidden">
          {/* Conversations List */}
          <div className="w-80 border-r border-gray-200 flex flex-col">
            <div className="p-3 border-b border-gray-200">
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Search className="h-4 w-4 text-gray-400" />
                </div>
                <input
                  type="text"
                  className="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md leading-5 bg-white placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                  placeholder="Search conversations..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
            </div>
            <div className="flex-1 overflow-y-auto">
              {filteredConversations.length > 0 ? (
                <div className="divide-y divide-gray-200">
                  {filteredConversations.map((conversation) => (
                    <div
                      key={conversation.id}
                      className={`p-4 hover:bg-gray-50 cursor-pointer flex items-center ${
                        selectedUser?.id === conversation.id ? 'bg-blue-50' : ''
                      }`}
                      onClick={() => handleSelectConversation(conversation)}
                    >
                      <div className="flex-shrink-0 h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center">
                        <UserIcon className="h-5 w-5 text-gray-500" />
                      </div>
                      <div className="ml-3 min-w-0 flex-1">
                        <div className="flex justify-between items-center">
                          <p className="text-sm font-medium text-gray-900 truncate">
                            {conversation.name}
                          </p>
                          {conversation.unread_count > 0 && (
                            <span className="inline-flex items-center justify-center px-2 py-1 text-xs font-bold leading-none text-white bg-blue-600 rounded-full">
                              {conversation.unread_count}
                            </span>
                          )}
                        </div>
                        <p className="text-sm text-gray-500 truncate">
                          {conversation.last_message?.content || 'No messages yet'}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="p-4 text-center text-gray-500">
                  No conversations yet
                  {searchTerm ? 'No matching conversations found' : 'No conversations yet'}
                </div>
              )}
            </div>
          </div>

          {/* Chat Area */}
          <div className="flex-1 flex flex-col">
            {selectedUser ? (
              <>
                <div className="p-4 border-b border-gray-200 flex items-center">
                  <div className="flex-shrink-0 h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center">
                    <UserIcon className="h-5 w-5 text-gray-500" />
                  </div>
                  <div className="ml-3">
                    <h2 className="font-semibold text-gray-900">{selectedUser.name}</h2>
                    <p className="text-xs text-gray-500">
                      {selectedUser.is_online ? 'Online' : 'Offline'}
                    </p>
                  </div>
                </div>

                <div className="flex-1 p-4 overflow-y-auto bg-gray-50">
                  <div className="space-y-4">
                    {messages.length > 0 ? (
                      messages.map((msg) => (
                        <div
                          key={msg.id || msg.tempId}
                          className={`flex ${msg.is_sender ? 'justify-end' : 'justify-start'}`}
                        >
                          <div
                            className={`max-w-3xl px-4 py-2 rounded-lg ${
                              msg.is_sender
                                ? 'bg-blue-600 text-white rounded-br-none'
                                : 'bg-white border border-gray-200 text-gray-800 rounded-bl-none shadow-sm'
                            }`}
                          >
                            <p className="whitespace-pre-wrap break-words">{msg.content}</p>
                            <p
                              className={`text-xs mt-1 ${
                                msg.is_sender ? 'text-blue-100' : 'text-gray-500'
                              }`}
                            >
                              {new Date(msg.timestamp).toLocaleTimeString([], {
                                hour: '2-digit',
                                minute: '2-digit',
                              })}
                              {msg.isSending && ' · Sending...'}
                            </p>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="text-center text-gray-500 py-8">
                        No messages yet. Start the conversation!
                      </div>
                    )}
                    <div ref={messagesEndRef} />
                  </div>
                </div>

                <div className="p-4 border-t border-gray-200">
                  <form onSubmit={handleSendMessage}>
                    <div className="flex space-x-2">
                      <input
                        type="text"
                        value={newMessage}
                        onChange={(e) => setNewMessage(e.target.value)}
                        placeholder="Type a message..."
                        className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                        disabled={!selectedUser}
                      />
                      <button
                        type="submit"
                        disabled={!newMessage.trim() || !selectedUser}
                        className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        <Send className="w-5 h-5" />
                      </button>
                    </div>
                  </form>
                </div>
              </>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center bg-gray-50">
                <div className="text-center p-6">
                  <UserIcon className="mx-auto h-12 w-12 text-gray-400" />
                  <h3 className="mt-2 text-lg font-medium text-gray-900">No conversation selected</h3>
                  <p className="mt-1 text-sm text-gray-500">
                    Select a conversation or start a new one
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}
