import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { Search, Plus, DollarSign, Clock, Filter, X, SlidersHorizontal } from 'lucide-react'
import api from '../api/axios'

export default function Projects({ user }) {
  const [projects, setProjects] = useState([])
  const [allProjects, setAllProjects] = useState([])
  const [filteredProjects, setFilteredProjects] = useState([])
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('all')
  const [showModal, setShowModal] = useState(false)
  const [showFilters, setShowFilters] = useState(false)
  
  // Freelancer filters
  const [filters, setFilters] = useState({
    minBudget: '',
    maxBudget: '',
    skills: [],
    duration: 'all',
    sortBy: 'newest'
  })
  
  const [formData, setFormData] = useState({
    title: '', description: '', budget: '', duration: '', skills_required: ''
  })

  // Common skills for filtering
  const commonSkills = [
    'React', 'JavaScript', 'Python', 'Node.js', 'TypeScript',
    'Vue.js', 'Angular', 'PHP', 'Java', 'C++',
    'Ruby', 'Go', 'Swift', 'Kotlin', 'Flutter',
    'UI/UX Design', 'Graphic Design', 'WordPress', 'SEO',
    'Content Writing', 'Data Science', 'Machine Learning',
    'DevOps', 'AWS', 'Docker', 'MongoDB', 'PostgreSQL'
  ]

  useEffect(() => {
    fetchProjects()
  }, [search])

  useEffect(() => {
    if (user.role === 'client') {
      filterProjects()
    } else {
      applyFreelancerFilters()
    }
  }, [statusFilter, allProjects, filters])

  const fetchProjects = async () => {
    try {
      // For clients, fetch only their own projects (all statuses)
      // For freelancers, fetch all open projects
      const endpoint = user.role === 'client' 
        ? `/projects?search=${search}&client_id=${user.id}`
        : `/projects?search=${search}`
      const res = await api.get(endpoint)
      setAllProjects(res.data)
      setProjects(res.data)
    } catch (err) {
      console.error(err)
    }
  }

  const filterProjects = () => {
    if (statusFilter === 'all') {
      setProjects(allProjects)
    } else {
      setProjects(allProjects.filter(p => p.status === statusFilter))
    }
  }

  const applyFreelancerFilters = () => {
    let filtered = [...allProjects]

    // Budget filter
    if (filters.minBudget) {
      filtered = filtered.filter(p => p.budget >= parseFloat(filters.minBudget))
    }
    if (filters.maxBudget) {
      filtered = filtered.filter(p => p.budget <= parseFloat(filters.maxBudget))
    }

    // Skills filter
    if (filters.skills.length > 0) {
      filtered = filtered.filter(p => 
        filters.skills.some(skill => 
          p.skills_required.some(pSkill => 
            pSkill.toLowerCase().includes(skill.toLowerCase())
          )
        )
      )
    }

    // Duration filter
    if (filters.duration !== 'all') {
      filtered = filtered.filter(p => {
        if (!p.duration) return false
        const duration = p.duration.toLowerCase()
        switch (filters.duration) {
          case 'short':
            return duration.includes('day') || duration.includes('week')
          case 'medium':
            return duration.includes('month') && !duration.includes('months')
          case 'long':
            return duration.includes('months') || duration.includes('year')
          default:
            return true
        }
      })
    }

    // Sorting
    switch (filters.sortBy) {
      case 'newest':
        filtered.sort((a, b) => new Date(b.created_at) - new Date(a.created_at))
        break
      case 'oldest':
        filtered.sort((a, b) => new Date(a.created_at) - new Date(b.created_at))
        break
      case 'budget_high':
        filtered.sort((a, b) => b.budget - a.budget)
        break
      case 'budget_low':
        filtered.sort((a, b) => a.budget - b.budget)
        break
      case 'proposals':
        filtered.sort((a, b) => a.proposal_count - b.proposal_count)
        break
      default:
        break
    }

    setProjects(filtered)
  }

  const toggleSkillFilter = (skill) => {
    setFilters(prev => ({
      ...prev,
      skills: prev.skills.includes(skill)
        ? prev.skills.filter(s => s !== skill)
        : [...prev.skills, skill]
    }))
  }

  const clearFilters = () => {
    setFilters({
      minBudget: '',
      maxBudget: '',
      skills: [],
      duration: 'all',
      sortBy: 'newest'
    })
  }

  const getActiveFilterCount = () => {
    let count = 0
    if (filters.minBudget || filters.maxBudget) count++
    if (filters.skills.length > 0) count++
    if (filters.duration !== 'all') count++
    return count
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    
    // Check if user is a client
    if (user.role !== 'client') {
      alert('Only clients can create projects. You are logged in as a ' + user.role + '.')
      return
    }
    
    try {
      const response = await api.post('/projects', {
        ...formData,
        budget: parseFloat(formData.budget),
        skills_required: formData.skills_required.split(',').map(s => s.trim())
      })
      
      if (response.status === 201) {
        setShowModal(false)
        setFormData({ title: '', description: '', budget: '', duration: '', skills_required: '' })
        fetchProjects()
        alert('Project created successfully!')
      }
    } catch (err) {
      console.error('Error creating project:', err)
      
      if (err.response?.status === 422) {
        alert('Authentication error. Please log in again.')
        return
      }
      
      const errorMsg = err.response?.data?.error || 'Failed to create project. Please try again.'
      alert('Error: ' + errorMsg)
    }
  }

  return (
    <div>
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Projects</h1>
        {user.role === 'client' && (
          <button
            onClick={() => setShowModal(true)}
            className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            <Plus className="w-4 h-4 mr-2" />
            Post Project
          </button>
        )}
      </div>

      {/* Search Bar and Filters */}
      <div className="mb-6 space-y-4">
        <div className="flex gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-3 w-5 h-5 text-gray-400" />
            <input
              type="text"
              placeholder="Search projects..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          {user.role === 'freelancer' && (
            <button
              onClick={() => setShowFilters(!showFilters)}
              className={`flex items-center px-4 py-2 rounded-lg font-medium transition ${
                showFilters || getActiveFilterCount() > 0
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              <SlidersHorizontal className="w-4 h-4 mr-2" />
              Filters
              {getActiveFilterCount() > 0 && (
                <span className="ml-2 px-2 py-0.5 bg-white text-blue-600 rounded-full text-xs font-bold">
                  {getActiveFilterCount()}
                </span>
              )}
            </button>
          )}
        </div>

        {/* Advanced Filters Panel (Freelancer Only) */}
        {user.role === 'freelancer' && showFilters && (
          <div className="bg-white rounded-lg shadow-lg p-6 space-y-6">
            <div className="flex justify-between items-center">
              <h3 className="text-lg font-semibold text-gray-900">Filter Projects</h3>
              <button
                onClick={clearFilters}
                className="text-sm text-blue-600 hover:text-blue-700 font-medium"
              >
                Clear All
              </button>
            </div>

            {/* Budget Range */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Budget Range
              </label>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                    <input
                      type="number"
                      placeholder="Min"
                      value={filters.minBudget}
                      onChange={(e) => setFilters({...filters, minBudget: e.target.value})}
                      className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>
                <div>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-3 w-4 h-4 text-gray-400" />
                    <input
                      type="number"
                      placeholder="Max"
                      value={filters.maxBudget}
                      onChange={(e) => setFilters({...filters, maxBudget: e.target.value})}
                      className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>
              </div>
            </div>

            {/* Skills Filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Skills ({filters.skills.length} selected)
              </label>
              <div className="flex flex-wrap gap-2 max-h-48 overflow-y-auto p-2 border border-gray-200 rounded-lg">
                {commonSkills.map(skill => (
                  <button
                    key={skill}
                    onClick={() => toggleSkillFilter(skill)}
                    className={`px-3 py-1 rounded-full text-sm font-medium transition ${
                      filters.skills.includes(skill)
                        ? 'bg-blue-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {skill}
                  </button>
                ))}
              </div>
            </div>

            {/* Duration Filter */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Project Duration
              </label>
              <div className="grid grid-cols-4 gap-2">
                <button
                  onClick={() => setFilters({...filters, duration: 'all'})}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition ${
                    filters.duration === 'all'
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  All
                </button>
                <button
                  onClick={() => setFilters({...filters, duration: 'short'})}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition ${
                    filters.duration === 'short'
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  Short
                  <span className="block text-xs opacity-75">Days/Weeks</span>
                </button>
                <button
                  onClick={() => setFilters({...filters, duration: 'medium'})}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition ${
                    filters.duration === 'medium'
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  Medium
                  <span className="block text-xs opacity-75">1 Month</span>
                </button>
                <button
                  onClick={() => setFilters({...filters, duration: 'long'})}
                  className={`px-4 py-2 rounded-lg text-sm font-medium transition ${
                    filters.duration === 'long'
                      ? 'bg-blue-600 text-white'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                  }`}
                >
                  Long
                  <span className="block text-xs opacity-75">Months+</span>
                </button>
              </div>
            </div>

            {/* Sort By */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-3">
                Sort By
              </label>
              <select
                value={filters.sortBy}
                onChange={(e) => setFilters({...filters, sortBy: e.target.value})}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="newest">Newest First</option>
                <option value="oldest">Oldest First</option>
                <option value="budget_high">Highest Budget</option>
                <option value="budget_low">Lowest Budget</option>
                <option value="proposals">Fewest Proposals</option>
              </select>
            </div>
          </div>
        )}
      </div>

      {/* Status Filter Tabs (Client Only) */}
      {user.role === 'client' && (
        <div className="mb-6 flex space-x-2 overflow-x-auto">
          <button
            onClick={() => setStatusFilter('all')}
            className={`px-4 py-2 rounded-lg font-medium transition ${
              statusFilter === 'all'
                ? 'bg-blue-600 text-white'
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
          >
            All Projects ({allProjects.length})
          </button>
          <button
            onClick={() => setStatusFilter('open')}
            className={`px-4 py-2 rounded-lg font-medium transition ${
              statusFilter === 'open'
                ? 'bg-green-600 text-white'
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
          >
            Open ({allProjects.filter(p => p.status === 'open').length})
          </button>
          <button
            onClick={() => setStatusFilter('in_progress')}
            className={`px-4 py-2 rounded-lg font-medium transition ${
              statusFilter === 'in_progress'
                ? 'bg-blue-600 text-white'
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
          >
            In Progress ({allProjects.filter(p => p.status === 'in_progress').length})
          </button>
          <button
            onClick={() => setStatusFilter('completed')}
            className={`px-4 py-2 rounded-lg font-medium transition ${
              statusFilter === 'completed'
                ? 'bg-purple-600 text-white'
                : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
            }`}
          >
            Completed ({allProjects.filter(p => p.status === 'completed').length})
          </button>
        </div>
      )}

      {/* Results Summary */}
      {user.role === 'freelancer' && (
        <div className="mb-4 flex items-center justify-between">
          <p className="text-sm text-gray-600">
            Showing <span className="font-semibold text-gray-900">{projects.length}</span> of{' '}
            <span className="font-semibold text-gray-900">{allProjects.length}</span> projects
          </p>
          {getActiveFilterCount() > 0 && (
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-600">Active filters:</span>
              {filters.skills.map(skill => (
                <span
                  key={skill}
                  className="inline-flex items-center px-2 py-1 bg-blue-100 text-blue-700 rounded text-xs"
                >
                  {skill}
                  <button
                    onClick={() => toggleSkillFilter(skill)}
                    className="ml-1 hover:text-blue-900"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </span>
              ))}
              {(filters.minBudget || filters.maxBudget) && (
                <span className="inline-flex items-center px-2 py-1 bg-green-100 text-green-700 rounded text-xs">
                  ${filters.minBudget || '0'} - ${filters.maxBudget || '∞'}
                </span>
              )}
              {filters.duration !== 'all' && (
                <span className="inline-flex items-center px-2 py-1 bg-purple-100 text-purple-700 rounded text-xs">
                  {filters.duration} duration
                </span>
              )}
            </div>
          )}
        </div>
      )}

      <div className="grid grid-cols-1 gap-6">
        {projects.length === 0 ? (
          <div className="bg-white rounded-lg shadow p-8 text-center text-gray-500">
            {user.role === 'client' 
              ? 'No projects yet. Click "Post Project" to get started!'
              : getActiveFilterCount() > 0
                ? 'No projects match your filters. Try adjusting your criteria.'
                : 'No projects available at the moment.'}
          </div>
        ) : (
          projects.map(project => (
            <Link key={project.id} to={`/projects/${project.id}`} className="bg-white rounded-lg shadow hover:shadow-lg transition p-6">
              <div className="flex justify-between items-start mb-2">
                <h3 className="text-xl font-semibold text-gray-900">{project.title}</h3>
                {user.role === 'client' && (
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                    project.status === 'open' ? 'bg-green-100 text-green-700' :
                    project.status === 'in_progress' ? 'bg-blue-100 text-blue-700' :
                    project.status === 'completed' ? 'bg-purple-100 text-purple-700' :
                    'bg-gray-100 text-gray-700'
                  }`}>
                    {project.status === 'in_progress' ? 'In Progress' : 
                     project.status.charAt(0).toUpperCase() + project.status.slice(1)}
                  </span>
                )}
              </div>
              <p className="text-gray-600 mb-4">{project.description.substring(0, 200)}...</p>
              <div className="flex flex-wrap gap-2 mb-4">
                {project.skills_required.map((skill, i) => (
                  <span key={i} className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm">
                    {skill}
                  </span>
                ))}
              </div>
              <div className="flex items-center justify-between text-sm text-gray-500">
                <div className="flex items-center space-x-4">
                  <span className="flex items-center">
                    <DollarSign className="w-4 h-4 mr-1" />
                    ${project.budget}
                  </span>
                  <span className="flex items-center">
                    <Clock className="w-4 h-4 mr-1" />
                    {project.duration || 'Not specified'}
                  </span>
                </div>
                <span className="text-blue-600">{project.proposal_count} proposals</span>
              </div>
            </Link>
          ))
        )}
      </div>

      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-8 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <h2 className="text-2xl font-bold mb-6">Post a New Project</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Project Title</label>
                <input
                  type="text"
                  value={formData.title}
                  onChange={(e) => setFormData({...formData, title: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  rows="4"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Budget ($)</label>
                  <input
                    type="number"
                    value={formData.budget}
                    onChange={(e) => setFormData({...formData, budget: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Duration</label>
                  <input
                    type="text"
                    value={formData.duration}
                    onChange={(e) => setFormData({...formData, duration: e.target.value})}
                    placeholder="e.g., 2 weeks"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Skills Required (comma-separated)</label>
                <input
                  type="text"
                  value={formData.skills_required}
                  onChange={(e) => setFormData({...formData, skills_required: e.target.value})}
                  placeholder="React, Python, Design"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div className="flex justify-end space-x-3 mt-6">
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Post Project
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
