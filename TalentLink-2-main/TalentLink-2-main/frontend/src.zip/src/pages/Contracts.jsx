import { useState, useEffect } from 'react'
import { DollarSign, Calendar, CheckCircle, Star, MessageSquare, TrendingUp, CreditCard, AlertCircle } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import api from '../api/axios'
import MilestoneManager from '../components/MilestoneManager'
import ContractDetail from '../components/ContractDetail'

export default function Contracts({ user }) {
  const navigate = useNavigate()
  const [contracts, setContracts] = useState([])
  const [showReviewModal, setShowReviewModal] = useState(false)
  const [selectedContract, setSelectedContract] = useState(null)
  const [showMilestoneManager, setShowMilestoneManager] = useState(null)
  const [showContractDetail, setShowContractDetail] = useState(null)
  const [reviewData, setReviewData] = useState({ rating: 5, comment: '' })

  useEffect(() => {
    fetchContracts()
  }, [])

  const fetchContracts = async () => {
    try {
      const res = await api.get('/contracts')
      setContracts(res.data)
    } catch (err) {
      console.error(err)
    }
  }

  const handleCompleteContract = async (contractId) => {
    try {
      await api.post(`/contracts/${contractId}/complete`)
      alert('Contract marked as completed!')
      fetchContracts()
    } catch (err) {
      console.error(err)
    }
  }

  const handleSubmitReview = async (e) => {
    e.preventDefault()
    try {
      await api.post('/reviews', {
        project_id: selectedContract.project.id,
        reviewee_id: user.role === 'client' ? selectedContract.freelancer.id : selectedContract.project.client_id,
        rating: reviewData.rating,
        comment: reviewData.comment
      })
      setShowReviewModal(false)
      alert('Review submitted successfully!')
      setReviewData({ rating: 5, comment: '' })
    } catch (err) {
      console.error(err)
    }
  }

  const getPaymentStatusBadge = (status) => {
    switch (status) {
      case 'paid':
        return <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-medium flex items-center">
          <CheckCircle className="w-3 h-3 mr-1" />
          Paid
        </span>
      case 'partially_paid':
        return <span className="px-3 py-1 bg-yellow-100 text-yellow-700 rounded-full text-xs font-medium flex items-center">
          <AlertCircle className="w-3 h-3 mr-1" />
          Partially Paid
        </span>
      case 'not_paid':
        return <span className="px-3 py-1 bg-red-100 text-red-700 rounded-full text-xs font-medium flex items-center">
          <CreditCard className="w-3 h-3 mr-1" />
          Not Paid
        </span>
      default:
        return null
    }
  }

  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Contracts</h1>

      <div className="grid grid-cols-1 gap-6">
        {contracts.length === 0 ? (
          <div className="bg-white rounded-lg shadow p-8 text-center text-gray-500">
            No contracts yet
          </div>
        ) : (
          contracts.map(contract => (
            <div key={contract.id} className="bg-white rounded-lg shadow p-6">
              <div className="flex justify-between items-start mb-4">
                <div className="flex-1">
                  <h3 className="text-xl font-semibold text-gray-900">{contract.project.title}</h3>
                  <p className="text-gray-600 mt-1">
                    {user.role === 'client' ? `Freelancer: ${contract.freelancer.name}` : `Client: ${contract.project.client_name}`}
                  </p>
                </div>
                <div className="flex items-center space-x-2">
                  <button 
                    onClick={() => {
                      const recipientId = user.role === 'client' 
                        ? contract.freelancer.id 
                        : contract.project.client_id;
                      navigate(`/messages?user=${recipientId}`);
                    }}
                    className="p-2 text-gray-600 hover:text-blue-600 hover:bg-blue-50 rounded-full"
                    title="Send message"
                  >
                    <MessageSquare className="w-5 h-5" />
                  </button>
                  <span className={`px-3 py-1 rounded-full text-sm ${
                    contract.status === 'active' ? 'bg-green-100 text-green-700' :
                    contract.status === 'completed' ? 'bg-blue-100 text-blue-700' :
                    'bg-gray-100 text-gray-700'
                  }`}>
                    {contract.status}
                  </span>
                </div>
              </div>

              {/* Payment Status Section */}
              <div className="bg-gray-50 rounded-lg p-4 mb-4">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium text-gray-700">Payment Status</span>
                  {getPaymentStatusBadge(contract.payment_status)}
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Total Amount:</span>
                    <span className="font-semibold text-gray-900">${contract.amount}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Paid:</span>
                    <span className="font-semibold text-green-600">${contract.total_paid}</span>
                  </div>
                  {contract.remaining_amount > 0 && (
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-600">Remaining:</span>
                      <span className="font-semibold text-red-600">${contract.remaining_amount}</span>
                    </div>
                  )}
                  {/* Progress Bar */}
                  <div className="mt-2">
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-green-500 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${contract.payment_percentage}%` }}
                      ></div>
                    </div>
                    <p className="text-xs text-gray-500 mt-1 text-right">{contract.payment_percentage}% paid</p>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-4">
                <div className="flex items-center text-gray-600">
                  <Calendar className="w-4 h-4 mr-2" />
                  <span>Started: {new Date(contract.start_date).toLocaleDateString()}</span>
                </div>
                {contract.end_date && (
                  <div className="flex items-center text-gray-600">
                    <CheckCircle className="w-4 h-4 mr-2" />
                    <span>Ended: {new Date(contract.end_date).toLocaleDateString()}</span>
                  </div>
                )}
              </div>

              <div className="flex flex-wrap gap-3">
                <button
                  onClick={() => setShowContractDetail(contract.id)}
                  className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  <CreditCard className="w-4 h-4 mr-2" />
                  View Details & Payments
                </button>
                {contract.status === 'active' && user.role === 'freelancer' && (
                  <button
                    onClick={() => setShowMilestoneManager(
                      showMilestoneManager === contract.id ? null : contract.id
                    )}
                    className="flex items-center px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700"
                  >
                    <TrendingUp className="w-4 h-4 mr-2" />
                    {showMilestoneManager === contract.id ? 'Hide' : 'Update'} Progress
                  </button>
                )}
                {contract.status === 'active' && user.role === 'client' && (
                  <button
                    onClick={() => handleCompleteContract(contract.id)}
                    className="flex items-center px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                  >
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Mark as Completed
                  </button>
                )}
                {contract.status === 'completed' && (
                  <button
                    onClick={() => {
                      setSelectedContract(contract)
                      setShowReviewModal(true)
                    }}
                    className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                  >
                    <Star className="w-4 h-4 mr-2" />
                    Leave Review
                  </button>
                )}
              </div>

              {/* Milestone Manager */}
              {showMilestoneManager === contract.id && user.role === 'freelancer' && (
                <div className="mt-6 pt-6 border-t border-gray-200">
                  <MilestoneManager 
                    projectId={contract.project.id} 
                    onUpdate={fetchContracts}
                  />
                </div>
              )}
            </div>
          ))
        )}
      </div>

      {/* Contract Detail Modal */}
      {showContractDetail && (
        <ContractDetail
          contractId={showContractDetail}
          user={user}
          onClose={() => {
            setShowContractDetail(null)
            fetchContracts()
          }}
        />
      )}

      {showReviewModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg p-8 max-w-md w-full">
            <h2 className="text-2xl font-bold mb-6">Leave a Review</h2>
            <form onSubmit={handleSubmitReview} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Rating</label>
                <div className="flex space-x-2">
                  {[1, 2, 3, 4, 5].map(rating => (
                    <button
                      key={rating}
                      type="button"
                      onClick={() => setReviewData({...reviewData, rating})}
                      className="focus:outline-none"
                    >
                      <Star
                        className={`w-8 h-8 ${rating <= reviewData.rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`}
                      />
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Comment</label>
                <textarea
                  value={reviewData.comment}
                  onChange={(e) => setReviewData({...reviewData, comment: e.target.value})}
                  rows="4"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <div className="flex justify-end space-x-3 mt-6">
                <button
                  type="button"
                  onClick={() => setShowReviewModal(false)}
                  className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Submit Review
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  )
}
