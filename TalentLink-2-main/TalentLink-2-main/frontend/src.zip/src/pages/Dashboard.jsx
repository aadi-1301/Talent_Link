import { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { Briefcase, FileText, DollarSign, TrendingUp } from 'lucide-react'
import api from '../api/axios'

export default function Dashboard({ user }) {
  const [stats, setStats] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    fetchDashboard()
  }, [])

  const fetchDashboard = async () => {
    try {
      const res = await api.get('/dashboard')
      setStats(res.data)
    } catch (err) {
      console.error('Dashboard error:', err)
      setStats(user.role === 'client' ? {
        total_projects: 0,
        active_projects: 0,
        completed_projects: 0,
        total_proposals: 0
      } : {
        total_proposals: 0,
        accepted_proposals: 0,
        active_contracts: 0,
        completed_contracts: 0,
        total_earnings: 0
      })
    } finally {
      setLoading(false)
    }
  }

  if (loading) return <div className="flex items-center justify-center h-64">Loading...</div>
  if (!stats) return <div className="flex items-center justify-center h-64">Error loading dashboard</div>

  return (
    <div>
      <h1 className="text-3xl font-bold text-gray-900 mb-8">Dashboard</h1>
      
      {user.role === 'client' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatCard icon={<Briefcase />} title="Total Projects" value={stats.total_projects} color="blue" />
          <StatCard icon={<TrendingUp />} title="Active Projects" value={stats.active_projects} color="green" />
          <StatCard icon={<FileText />} title="Completed" value={stats.completed_projects} color="purple" />
          <StatCard icon={<DollarSign />} title="Total Proposals" value={stats.total_proposals} color="orange" />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatCard icon={<FileText />} title="Total Proposals" value={stats.total_proposals} color="blue" />
          <StatCard icon={<TrendingUp />} title="Accepted" value={stats.accepted_proposals} color="green" />
          <StatCard icon={<Briefcase />} title="Active Contracts" value={stats.active_contracts} color="purple" />
          <StatCard icon={<DollarSign />} title="Total Earnings" value={`$${stats.total_earnings}`} color="orange" />
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">Quick Actions</h2>
          <div className="space-y-3">
            {user.role === 'client' ? (
              <>
                <Link to="/projects" className="block p-4 bg-blue-50 rounded-lg hover:bg-blue-100 transition">
                  <h3 className="font-semibold text-blue-900">Post a New Project</h3>
                  <p className="text-sm text-blue-700">Find talented freelancers for your project</p>
                </Link>
                <Link to="/find-freelancers" className="block p-4 bg-purple-50 rounded-lg hover:bg-purple-100 transition">
                  <h3 className="font-semibold text-purple-900">Find Freelancers</h3>
                  <p className="text-sm text-purple-700">Browse and connect with talented freelancers</p>
                </Link>
                <Link to="/contracts" className="block p-4 bg-green-50 rounded-lg hover:bg-green-100 transition">
                  <h3 className="font-semibold text-green-900">View Contracts</h3>
                  <p className="text-sm text-green-700">Manage your active contracts</p>
                </Link>
              </>
            ) : (
              <>
                <Link to="/projects" className="block p-4 bg-blue-50 rounded-lg hover:bg-blue-100 transition">
                  <h3 className="font-semibold text-blue-900">Browse Projects</h3>
                  <p className="text-sm text-blue-700">Find projects that match your skills</p>
                </Link>
                <Link to="/profile" className="block p-4 bg-purple-50 rounded-lg hover:bg-purple-100 transition">
                  <h3 className="font-semibold text-purple-900">Update Profile</h3>
                  <p className="text-sm text-purple-700">Showcase your skills and portfolio</p>
                </Link>
              </>
            )}
          </div>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h2 className="text-xl font-semibold mb-4">Recent Activity</h2>
          <p className="text-gray-500">No recent activity</p>
        </div>
      </div>
    </div>
  )
}

function StatCard({ icon, title, value, color }) {
  const colors = {
    blue: 'bg-blue-500',
    green: 'bg-green-500',
    purple: 'bg-purple-500',
    orange: 'bg-orange-500'
  }

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm text-gray-600">{title}</p>
          <p className="text-2xl font-bold text-gray-900 mt-1">{value}</p>
        </div>
        <div className={`${colors[color]} p-3 rounded-lg text-white`}>
          {icon}
        </div>
      </div>
    </div>
  )
}
