import { useState, useEffect } from 'react'
import { Save, Plus, CheckCircle, Clock, Circle } from 'lucide-react'
import api from '../api/axios'

export default function MilestoneManager({ projectId, onUpdate }) {
  const [milestones, setMilestones] = useState([])
  const [loading, setLoading] = useState(true)
  const [selectedMilestone, setSelectedMilestone] = useState(null)
  const [updateContent, setUpdateContent] = useState('')
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    fetchMilestones()
  }, [projectId])

  const fetchMilestones = async () => {
    try {
      const res = await api.get(`/projects/${projectId}/milestones`)
      if (res.data.length === 0) {
        // Create default milestones
        await api.post(`/projects/${projectId}/milestones`)
        const newRes = await api.get(`/projects/${projectId}/milestones`)
        setMilestones(newRes.data)
      } else {
        setMilestones(res.data)
      }
    } catch (err) {
      console.error('Error fetching milestones:', err)
    } finally {
      setLoading(false)
    }
  }

  const handleUpdateMilestone = async (milestoneId, updates) => {
    setSaving(true)
    try {
      await api.put(`/milestones/${milestoneId}`, updates)
      await fetchMilestones()
      if (onUpdate) onUpdate()
      alert('Milestone updated successfully!')
    } catch (err) {
      console.error('Error updating milestone:', err)
      alert('Failed to update milestone')
    } finally {
      setSaving(false)
    }
  }

  const handleAddUpdate = async (milestoneId) => {
    if (!updateContent.trim()) {
      alert('Please enter an update message')
      return
    }

    setSaving(true)
    try {
      const milestone = milestones.find(m => m.id === milestoneId)
      await api.post(`/milestones/${milestoneId}/updates`, {
        content: updateContent,
        progress: milestone.progress
      })
      setUpdateContent('')
      setSelectedMilestone(null)
      await fetchMilestones()
      if (onUpdate) onUpdate()
      alert('Update added successfully!')
    } catch (err) {
      console.error('Error adding update:', err)
      alert('Failed to add update')
    } finally {
      setSaving(false)
    }
  }

  const handleProgressChange = (milestoneId, newProgress) => {
    setMilestones(milestones.map(m =>
      m.id === milestoneId ? { ...m, progress: newProgress } : m
    ))
  }

  const handleStatusChange = (milestoneId, newStatus) => {
    const milestone = milestones.find(m => m.id === milestoneId)
    handleUpdateMilestone(milestoneId, {
      status: newStatus,
      progress: newStatus === 'completed' ? 100 : milestone.progress
    })
  }

  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-5 h-5 text-green-600" />
      case 'in_progress':
        return <Clock className="w-5 h-5 text-blue-600" />
      default:
        return <Circle className="w-5 h-5 text-gray-400" />
    }
  }

  if (loading) {
    return <div className="text-center py-8">Loading milestones...</div>
  }

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg p-6 text-white">
        <h2 className="text-2xl font-bold mb-2">Project Milestones</h2>
        <p className="text-blue-100">Update your progress and keep the client informed</p>
      </div>

      <div className="space-y-4">
        {milestones.map((milestone) => (
          <div key={milestone.id} className="bg-white rounded-lg shadow-md p-6">
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center space-x-3">
                {getStatusIcon(milestone.status)}
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">{milestone.name}</h3>
                  <p className="text-sm text-gray-600">{milestone.description}</p>
                </div>
              </div>
              <select
                value={milestone.status}
                onChange={(e) => handleStatusChange(milestone.id, e.target.value)}
                className="px-3 py-1 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                disabled={saving}
              >
                <option value="pending">Pending</option>
                <option value="in_progress">In Progress</option>
                <option value="completed">Completed</option>
              </select>
            </div>

            {/* Progress Slider */}
            <div className="mb-4">
              <div className="flex justify-between items-center mb-2">
                <label className="text-sm font-medium text-gray-700">Progress</label>
                <span className="text-lg font-bold text-blue-600">{milestone.progress}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={milestone.progress}
                onChange={(e) => handleProgressChange(milestone.id, parseInt(e.target.value))}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                disabled={milestone.status === 'completed'}
              />
              <div className="w-full bg-gray-200 rounded-full h-3 mt-2">
                <div
                  className={`h-3 rounded-full transition-all duration-300 ${
                    milestone.status === 'completed'
                      ? 'bg-green-500'
                      : 'bg-blue-500'
                  }`}
                  style={{ width: `${milestone.progress}%` }}
                ></div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex space-x-3">
              <button
                onClick={() => handleUpdateMilestone(milestone.id, { progress: milestone.progress })}
                disabled={saving || milestone.status === 'completed'}
                className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Save className="w-4 h-4 mr-2" />
                Save Progress
              </button>
              <button
                onClick={() => setSelectedMilestone(milestone.id)}
                className="flex items-center px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300"
              >
                <Plus className="w-4 h-4 mr-2" />
                Add Update
              </button>
            </div>

            {/* Add Update Form */}
            {selectedMilestone === milestone.id && (
              <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Update Message
                </label>
                <textarea
                  value={updateContent}
                  onChange={(e) => setUpdateContent(e.target.value)}
                  rows="3"
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Describe what you've accomplished..."
                />
                <div className="flex justify-end space-x-2 mt-3">
                  <button
                    onClick={() => {
                      setSelectedMilestone(null)
                      setUpdateContent('')
                    }}
                    className="px-4 py-2 text-gray-700 hover:bg-gray-200 rounded-lg"
                  >
                    Cancel
                  </button>
                  <button
                    onClick={() => handleAddUpdate(milestone.id)}
                    disabled={saving || !updateContent.trim()}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
                  >
                    {saving ? 'Posting...' : 'Post Update'}
                  </button>
                </div>
              </div>
            )}

            {/* Dates */}
            {(milestone.started_at || milestone.completed_at) && (
              <div className="mt-4 pt-4 border-t border-gray-200 text-xs text-gray-500 space-y-1">
                {milestone.started_at && (
                  <div>Started: {new Date(milestone.started_at).toLocaleString()}</div>
                )}
                {milestone.completed_at && (
                  <div>Completed: {new Date(milestone.completed_at).toLocaleString()}</div>
                )}
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  )
}
