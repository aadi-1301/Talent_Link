import { Outlet, Link, useNavigate } from 'react-router-dom'
import { Home, Briefcase, MessageSquare, FileText, User, LogOut, Bell, Users } from 'lucide-react'
import { useState, useEffect } from 'react'
import api from '../api/axios'

export default function Layout({ user, setUser }) {
  const navigate = useNavigate()
  const [notifications, setNotifications] = useState([])
  const [showNotifications, setShowNotifications] = useState(false)

  useEffect(() => {
    fetchNotifications()
    const interval = setInterval(fetchNotifications, 30000)
    return () => clearInterval(interval)
  }, [])

  const fetchNotifications = async () => {
    try {
      const res = await api.get('/notifications')
      setNotifications(res.data)
    } catch (err) {
      console.error('Notifications fetch error:', err)
      // Don't show error to user for notifications, just log it
      // The axios interceptor will handle 422 errors by redirecting to login
    }
  }

  const handleLogout = () => {
    localStorage.removeItem('token')
    localStorage.removeItem('user')
    setUser(null)
    navigate('/login')
  }

  const unreadCount = notifications.filter(n => !n.read).length

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex">
              <div className="flex-shrink-0 flex items-center">
                <h1 className="text-2xl font-bold text-blue-600">TalentLink</h1>
              </div>
              <div className="hidden sm:ml-8 sm:flex sm:space-x-8">
                <Link to="/dashboard" className="inline-flex items-center px-1 pt-1 text-gray-900 hover:text-blue-600">
                  <Home className="w-4 h-4 mr-2" />
                  Dashboard
                </Link>
                <Link to="/projects" className="inline-flex items-center px-1 pt-1 text-gray-900 hover:text-blue-600">
                  <Briefcase className="w-4 h-4 mr-2" />
                  Projects
                </Link>
                {user.role === 'client' && (
                  <Link to="/find-freelancers" className="inline-flex items-center px-1 pt-1 text-gray-900 hover:text-blue-600">
                    <Users className="w-4 h-4 mr-2" />
                    Find Freelancers
                  </Link>
                )}
                <Link to="/contracts" className="inline-flex items-center px-1 pt-1 text-gray-900 hover:text-blue-600">
                  <FileText className="w-4 h-4 mr-2" />
                  Contracts
                </Link>
                <Link to="/messages" className="inline-flex items-center px-1 pt-1 text-gray-900 hover:text-blue-600">
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Messages
                </Link>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <button onClick={() => setShowNotifications(!showNotifications)} className="relative p-2 text-gray-600 hover:text-blue-600">
                  <Bell className="w-5 h-5" />
                  {unreadCount > 0 && (
                    <span className="absolute top-0 right-0 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                      {unreadCount}
                    </span>
                  )}
                </button>
                {showNotifications && (
                  <div className="absolute right-0 mt-2 w-80 bg-white rounded-lg shadow-lg border z-50">
                    <div className="p-4 border-b">
                      <h3 className="font-semibold">Notifications</h3>
                    </div>
                    <div className="max-h-96 overflow-y-auto">
                      {notifications.length === 0 ? (
                        <p className="p-4 text-gray-500 text-center">No notifications</p>
                      ) : (
                        notifications.map(n => (
                          <div key={n.id} className={`p-4 border-b hover:bg-gray-50 ${!n.read ? 'bg-blue-50' : ''}`}>
                            <p className="text-sm">{n.content}</p>
                            <p className="text-xs text-gray-500 mt-1">{new Date(n.created_at).toLocaleString()}</p>
                          </div>
                        ))
                      )}
                    </div>
                  </div>
                )}
              </div>
              <Link to="/profile" className="flex items-center text-gray-700 hover:text-blue-600">
                <User className="w-5 h-5 mr-2" />
                <span className="hidden sm:block">{user.name}</span>
              </Link>
              <button onClick={handleLogout} className="flex items-center text-gray-700 hover:text-red-600">
                <LogOut className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>
      </nav>
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Outlet />
      </main>
    </div>
  )
}
